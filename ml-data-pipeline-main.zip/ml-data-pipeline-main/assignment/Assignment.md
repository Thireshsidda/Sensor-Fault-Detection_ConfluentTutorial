1. Use Avro format for consumer and producer instead of json.
2. Dump data in cassandra database instead of mongo db.
3. Dump data in s3 bukcet instead of mongodb.
4. Dump data in azure blob storage instead of mongodb.
5. Dump data in google cloud stoge instead of mongodb.
