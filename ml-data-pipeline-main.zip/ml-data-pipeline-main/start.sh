#!bin/sh
nohup python producer_main.py &
python consumer_main.py